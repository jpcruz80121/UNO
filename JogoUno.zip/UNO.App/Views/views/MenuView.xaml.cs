﻿using System.Windows.Controls;

namespace UNO.App.Views
{
    public partial class MenuView : UserControl
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}