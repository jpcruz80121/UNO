﻿using System.Windows.Controls;

namespace UNO.App.Views
{
    public partial class JogoView : UserControl
    {
        public JogoView()
        {
            InitializeComponent();
        }
    }
}