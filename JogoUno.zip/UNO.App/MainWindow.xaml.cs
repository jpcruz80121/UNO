﻿using System.Windows;
using UNO.App.ViewModels;

namespace UNO.App
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }
    }
}