﻿using System;
using System.Collections.Generic;

namespace UNO.App.Models
{
    public class Baralho
    {
        public List<Carta> Cartas { get; set; } = new List<Carta>();

        private Random random = new Random();

        public Baralho()
        {
            CriarBaralho();
            Embaralhar();
        }

        private void CriarBaralho()
        {
            foreach (Cor cor in new[] { Cor.Vermelho, Cor.Azul, Cor.Verde, Cor.Amarelo })
            {
                // Carta 0 (apenas 1)
                Cartas.Add(new Carta
                {
                    Cor = cor,
                    Tipo = TipoCarta.Numero,
                    Valor = 0
                });

                // Cartas 1-9 (2 de cada)
                for (int i = 1; i <= 9; i++)
                {
                    Cartas.Add(new Carta
                    {
                        Cor = cor,
                        Tipo = TipoCarta.Numero,
                        Valor = i
                    });

                    Cartas.Add(new Carta
                    {
                        Cor = cor,
                        Tipo = TipoCarta.Numero,
                        Valor = i
                    });
                }

                // Cartas especiais (2 de cada)
                for (int i = 0; i < 2; i++)
                {
                    Cartas.Add(new Carta
                    {
                        Cor = cor,
                        Tipo = TipoCarta.MaisDois
                    });

                    Cartas.Add(new Carta
                    {
                        Cor = cor,
                        Tipo = TipoCarta.Inverter
                    });

                    Cartas.Add(new Carta
                    {
                        Cor = cor,
                        Tipo = TipoCarta.Bloquear
                    });
                }
            }

            // Coringas
            for (int i = 0; i < 4; i++)
            {
                Cartas.Add(new Carta
                {
                    Cor = Cor.Especial,
                    Tipo = TipoCarta.Coringa
                });

                Cartas.Add(new Carta
                {
                    Cor = Cor.Especial,
                    Tipo = TipoCarta.MaisQuatro
                });
            }
        }

        public void Embaralhar()
        {
            int n = Cartas.Count;

            while (n > 1)
            {
                n--;

                int k = random.Next(n + 1);

                Carta value = Cartas[k];
                Cartas[k] = Cartas[n];
                Cartas[n] = value;
            }
        }

        public Carta ComprarCarta()
        {
            if (Cartas.Count == 0)
                return null;

            Carta carta = Cartas[0];

            Cartas.RemoveAt(0);

            return carta;
        }
    }
}