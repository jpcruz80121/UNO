﻿namespace UNO.App.Models
{
    public class Pontuacao
    {
        public Jogador Jogador { get; set; }

        public int PontosRodada { get; set; }

        public int PontosTotais { get; set; }

        public Pontuacao()
        {
        }

        public Pontuacao(Jogador jogador)
        {
            Jogador = jogador;
            PontosRodada = 0;
            PontosTotais = 0;
        }
    }
}