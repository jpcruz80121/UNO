﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace UNO.App.Models
{
    public class Jogo
    {
        private static readonly Random _random = new Random();

        public List<Jogador> Jogadores { get; set; } = new List<Jogador>();
        public Baralho Baralho { get; set; } = new Baralho();
        public List<Carta> PilhaDescarte { get; set; } = new List<Carta>();

        public int JogadorAtualIndex { get; set; }
        public bool SentidoHorario { get; set; } = true;
        public Cor? CorAtual { get; set; }

        public Jogador JogadorAtual => Jogadores[JogadorAtualIndex];
        public Carta CartaTopo => PilhaDescarte.LastOrDefault();

        public void IniciarJogo(int numeroBots)
        {
            Jogadores.Clear();

            Jogadores.Add(new Jogador
            {
                Nome = Environment.MachineName,
                EhBot = false,
                JogosJogados = 1
            });

            for (int i = 1; i <= numeroBots; i++)
            {
                Jogadores.Add(new Jogador
                {
                    Nome = "Bot " + i,
                    EhBot = true,
                    JogosJogados = 1
                });
            }

            IniciarNovaPartida();
        }

        public void IniciarNovaPartida()
        {
            PilhaDescarte.Clear();
            Baralho = new Baralho();

            foreach (var jogador in Jogadores)
            {
                jogador.PartidasJogadas++;
                jogador.Mao.Clear();
                jogador.DisseUno = false;

                for (int i = 0; i < 7; i++)
                    jogador.ComprarCarta(Baralho.ComprarCarta());
            }

            Carta primeiraCarta;

            do
            {
                primeiraCarta = Baralho.ComprarCarta();
            }
            while (primeiraCarta != null && primeiraCarta.Tipo != TipoCarta.Numero);

            PilhaDescarte.Add(primeiraCarta);
            CorAtual = primeiraCarta.Cor;

            SentidoHorario = true;

            if (Jogadores.Count > 0)
                JogadorAtualIndex = _random.Next(Jogadores.Count);
            else
                JogadorAtualIndex = 0;
        }

        public bool PodeJogar(Carta carta)
        {
            if (carta == null || CartaTopo == null)
                return false;

            if (carta.Tipo == TipoCarta.Coringa)
                return true;

            if (carta.Tipo == TipoCarta.MaisQuatro)
            {
                bool temCartaDaCorAtual = JogadorAtual.Mao.Any(c =>
                    c != carta &&
                    c.Cor == CorAtual &&
                    c.Cor != Cor.Especial);

                return !temCartaDaCorAtual;
            }

            if (carta.Cor == CorAtual)
                return true;

            if (carta.Tipo == TipoCarta.Numero &&
                CartaTopo.Tipo == TipoCarta.Numero &&
                carta.Valor == CartaTopo.Valor)
                return true;

            if (carta.Tipo != TipoCarta.Numero &&
                CartaTopo.Tipo != TipoCarta.Numero &&
                carta.Tipo == CartaTopo.Tipo)
                return true;

            return false;
        }

        public void JogarCarta(Carta carta, Cor? corEscolhida = null)
        {
            if (!PodeJogar(carta))
                return;

            JogadorAtual.JogarCarta(carta);
            PilhaDescarte.Add(carta);

            if (carta.Tipo == TipoCarta.Coringa || carta.Tipo == TipoCarta.MaisQuatro)
                CorAtual = corEscolhida ?? Cor.Vermelho;
            else
                CorAtual = carta.Cor;

            AplicarEfeitoCarta(carta);

            if (!VerificarVencedor())
                ProximoJogador();
        }

        public void ComprarCarta()
        {
            JogadorAtual.ComprarCarta(Baralho.ComprarCarta());
        }

        private void AplicarEfeitoCarta(Carta carta)
        {
            switch (carta.Tipo)
            {
                case TipoCarta.Inverter:
                    SentidoHorario = !SentidoHorario;
                    break;

                case TipoCarta.Bloquear:
                    ProximoJogador();
                    break;

                case TipoCarta.MaisDois:
                    ProximoJogador();
                    JogadorAtual.ComprarCarta(Baralho.ComprarCarta());
                    JogadorAtual.ComprarCarta(Baralho.ComprarCarta());
                    break;

                case TipoCarta.MaisQuatro:
                    ProximoJogador();

                    for (int i = 0; i < 4; i++)
                        JogadorAtual.ComprarCarta(Baralho.ComprarCarta());

                    break;
            }
        }

        public void ProximoJogador()
        {
            if (SentidoHorario)
                JogadorAtualIndex = (JogadorAtualIndex + 1) % Jogadores.Count;
            else
                JogadorAtualIndex = (JogadorAtualIndex - 1 + Jogadores.Count) % Jogadores.Count;
        }

        public bool VerificarVencedor()
        {
            return Jogadores.Any(j => j.Mao.Count == 0);
        }

        public Jogador ObterVencedor()
        {
            return Jogadores.FirstOrDefault(j => j.Mao.Count == 0);
        }

        public int CalcularPontosRodada()
        {
            int pontos = 0;

            foreach (var jogador in Jogadores)
            {
                foreach (var carta in jogador.Mao)
                    pontos += carta.ObterPontuacao();
            }

            return pontos;
        }

        public void AtribuirPontosAoVencedor()
        {
            var vencedor = ObterVencedor();

            if (vencedor != null)
            {
                vencedor.Pontos += CalcularPontosRodada();
                vencedor.PartidasGanhas++;

                if (vencedor.Pontos >= 500)
                    vencedor.JogosGanhos++;
            }
        }
    }
}