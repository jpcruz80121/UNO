﻿namespace UNO.App.Models
{
    public enum Cor
    {
        Vermelho,
        Azul,
        Verde,
        Amarelo,
        Especial
    }

    public enum TipoCarta
    {
        Numero,
        MaisDois,
        Inverter,
        Bloquear,
        Coringa,
        MaisQuatro
    }

    public class Carta
    {
        public Cor Cor { get; set; }
        public TipoCarta Tipo { get; set; }
        public int Valor { get; set; }

        public string TextoCarta
        {
            get
            {
                switch (Tipo)
                {
                    case TipoCarta.Numero:
                        return Valor.ToString();

                    case TipoCarta.MaisDois:
                        return "+2";

                    case TipoCarta.Inverter:
                        return "⮂";

                    case TipoCarta.Bloquear:
                        return "⊘";

                    case TipoCarta.Coringa:
                        return "W";

                    case TipoCarta.MaisQuatro:
                        return "+4";

                    default:
                        return "?";
                }
            }
        }

        public bool PodeJogar(Carta cartaMesa)
        {
            if (cartaMesa == null)
                return true;

            if (Tipo == TipoCarta.Coringa || Tipo == TipoCarta.MaisQuatro)
                return true;

            if (Cor == cartaMesa.Cor)
                return true;

            if (Tipo == TipoCarta.Numero &&
                cartaMesa.Tipo == TipoCarta.Numero &&
                Valor == cartaMesa.Valor)
                return true;

            if (Tipo != TipoCarta.Numero &&
                cartaMesa.Tipo != TipoCarta.Numero &&
                Tipo == cartaMesa.Tipo)
                return true;

            return false;
        }

        public int ObterPontuacao()
        {
            switch (Tipo)
            {
                case TipoCarta.Numero:
                    return Valor;

                case TipoCarta.MaisDois:
                case TipoCarta.Inverter:
                case TipoCarta.Bloquear:
                    return 20;

                case TipoCarta.Coringa:
                case TipoCarta.MaisQuatro:
                    return 50;

                default:
                    return 0;
            }
        }

        public override string ToString()
        {
            if (Tipo == TipoCarta.Numero)
                return $"{Cor} {Valor}";

            return $"{Tipo} - {Cor}";
        }
    }
}