﻿using System.Collections.Generic;
using System.Linq;

namespace UNO.App.Models
{
    public class Jogador
    {
        public string Nome { get; set; }

        public List<Carta> Mao { get; set; } = new List<Carta>();

        public int Pontos { get; set; }

        public bool EhBot { get; set; }

        public bool DisseUno { get; set; }

        public int PartidasJogadas { get; set; }

        public int PartidasGanhas { get; set; }

        public int JogosJogados { get; set; }

        public int JogosGanhos { get; set; }


        // NOVO → taxa de vitória para estatísticas
        public string TaxaVitoriaTexto
        {
            get
            {
                if (PartidasJogadas == 0)
                    return "0%";

                double taxa = ((double)PartidasGanhas / PartidasJogadas) * 100;

                return taxa.ToString("0.0") + "%";
            }
        }


        public void ComprarCarta(Carta carta)
        {
            if (carta != null)
                Mao.Add(carta);
        }

        public void JogarCarta(Carta carta)
        {
            if (Mao.Contains(carta))
                Mao.Remove(carta);
        }

        public List<Carta> ObterCartasJogaveis(Carta cartaMesa)
        {
            return Mao
                .Where(c => c.PodeJogar(cartaMesa))
                .ToList();
        }

        public bool TemCartaJogavel(Carta cartaMesa)
        {
            return Mao.Any(c => c.PodeJogar(cartaMesa));
        }
    }
}