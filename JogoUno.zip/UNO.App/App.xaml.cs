﻿using System.Windows;

namespace UNO.App
{
    /// <summary>
    /// Interação lógica para App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
