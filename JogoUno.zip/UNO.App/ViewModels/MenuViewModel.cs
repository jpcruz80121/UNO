﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using UNO.App.Commands;
using UNO.App.Services;

namespace UNO.App.ViewModels
{
    public class MenuViewModel : BaseViewModel
    {
        private readonly XmlService _xmlService = new XmlService();

        public ICommand EscolherBotsCommand { get; }
        public ICommand AbrirJogosGuardadosCommand { get; }
        public ICommand FecharJogosGuardadosCommand { get; }
        public ICommand RetomarJogoCommand { get; }
        public ICommand SairCommand { get; }

        public ObservableCollection<JogoGuardadoInfo> JogosGuardados { get; set; }

        private bool _jogosGuardadosVisivel;
        public bool JogosGuardadosVisivel
        {
            get => _jogosGuardadosVisivel;
            set
            {
                _jogosGuardadosVisivel = value;
                OnPropertyChanged();
            }
        }

        public MenuViewModel(ICommand escolherBotsCommand, ICommand retomarJogoCommand)
        {
            EscolherBotsCommand = escolherBotsCommand;
            RetomarJogoCommand = retomarJogoCommand;

            JogosGuardados = new ObservableCollection<JogoGuardadoInfo>();

            AbrirJogosGuardadosCommand = new RelayCommand(_ => AbrirJogosGuardados());
            FecharJogosGuardadosCommand = new RelayCommand(_ => JogosGuardadosVisivel = false);
            SairCommand = new RelayCommand(_ => System.Windows.Application.Current.Shutdown());
        }

        private void AbrirJogosGuardados()
        {
            JogosGuardados.Clear();

            foreach (var jogo in _xmlService.ListarJogosGuardados())
                JogosGuardados.Add(jogo);

            JogosGuardadosVisivel = true;
        }
    }
}