﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using UNO.App.Commands;
using UNO.App.Models;
using UNO.App.Services;
using System.Windows;

namespace UNO.App.ViewModels
{
    public class JogoViewModel : BaseViewModel
    {
        private Jogo _jogo = new Jogo();
        private XmlService _xmlService = new XmlService();
        private bool _partidaTerminada = false;
        private int _numeroBots;

        private int _indicePrimeiraCarta = 0;
        private const int MaxCartasVisiveis = 9;

        private Carta _cartaEspecialPendente;
        private bool _continuarBotsDepoisPenalizacao = false;

        public ObservableCollection<Jogador> Jogadores { get; set; }
        public ObservableCollection<Jogador> Bots { get; set; }
        public ObservableCollection<Carta> MaoJogador { get; set; }
        public ObservableCollection<Carta> MaoJogadorVisivel { get; set; }

        private bool _menuPausaVisivel;
        public bool MenuPausaVisivel
        {
            get => _menuPausaVisivel;
            set { _menuPausaVisivel = value; OnPropertyChanged(); }
        }

        private bool _confirmarSaidaVisivel;
        public bool ConfirmarSaidaVisivel
        {
            get => _confirmarSaidaVisivel;
            set { _confirmarSaidaVisivel = value; OnPropertyChanged(); }
        }

        private bool _estatisticasVisivel;
        public bool EstatisticasVisivel
        {
            get => _estatisticasVisivel;
            set { _estatisticasVisivel = value; OnPropertyChanged(); }
        }

        private bool _escolhaCorVisivel;
        public bool EscolhaCorVisivel
        {
            get => _escolhaCorVisivel;
            set { _escolhaCorVisivel = value; OnPropertyChanged(); }
        }

        private bool _penalizacaoUnoVisivel;
        public bool PenalizacaoUnoVisivel
        {
            get => _penalizacaoUnoVisivel;
            set { _penalizacaoUnoVisivel = value; OnPropertyChanged(); }
        }

        private string _penalizacaoJogador = "";
        public string PenalizacaoJogador
        {
            get => _penalizacaoJogador;
            set { _penalizacaoJogador = value; OnPropertyChanged(); }
        }

        public string DirecaoTexto => _jogo.SentidoHorario ? "↻" : "↺";

        private Carta _cartaTopo;
        public Carta CartaTopo
        {
            get => _cartaTopo;
            set { _cartaTopo = value; OnPropertyChanged(); }
        }

        private string _mensagem = "";
        public string Mensagem
        {
            get => _mensagem;
            set { _mensagem = value; OnPropertyChanged(); }
        }

        private string _pontuacoesTexto = "";
        public string PontuacoesTexto
        {
            get => _pontuacoesTexto;
            set { _pontuacoesTexto = value; OnPropertyChanged(); }
        }

        private Cor _corEscolhida = Cor.Vermelho;
        public Cor CorEscolhida
        {
            get => _corEscolhida;
            set
            {
                _corEscolhida = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CorAtual));
            }
        }

        public Cor CorAtual
        {
            get
            {
                if (CartaTopo != null && CartaTopo.Cor != Cor.Especial)
                    return CartaTopo.Cor;

                return CorEscolhida;
            }
        }

        public ICommand IniciarJogoCommand { get; private set; }
        public ICommand JogarCartaCommand { get; private set; }
        public ICommand ComprarCartaCommand { get; private set; }
        public ICommand GritarUnoCommand { get; private set; }
        public ICommand EscolherCorCommand { get; private set; }
        public ICommand GuardarJogoCommand { get; private set; }
        public ICommand CarregarJogoCommand { get; private set; }
        public ICommand NovaPartidaCommand { get; private set; }
        public ICommand NovoJogoCommand { get; private set; }
        public ICommand AbrirPausaCommand { get; private set; }
        public ICommand FecharPausaCommand { get; private set; }
        public ICommand SairCommand { get; private set; }
        public ICommand AbrirEstatisticasCommand { get; private set; }
        public ICommand FecharEstatisticasCommand { get; private set; }
        public ICommand GuardarESairCommand { get; private set; }
        public ICommand SairSemGuardarCommand { get; private set; }
        public ICommand VoltarAoJogoCommand { get; private set; }
        public ICommand VoltarMenuCommand { get; private set; }
        public ICommand CartasAnterioresCommand { get; private set; }
        public ICommand CartasSeguintesCommand { get; private set; }
        public ICommand FecharPenalizacaoCommand { get; private set; }

        public JogoViewModel(int numeroBots)
        {
            _numeroBots = numeroBots;
            InicializarColecoes();
            InicializarComandos();
            IniciarJogo();
        }

        public JogoViewModel(Jogo jogoCarregado)
        {
            _jogo = jogoCarregado;
            _numeroBots = Math.Max(1, _jogo.Jogadores.Count(j => j.EhBot));

            InicializarColecoes();
            InicializarComandos();

            _partidaTerminada = _jogo.VerificarVencedor();
            MenuPausaVisivel = false;
            ConfirmarSaidaVisivel = false;
            EstatisticasVisivel = false;
            EscolhaCorVisivel = false;
            PenalizacaoUnoVisivel = false;
            _continuarBotsDepoisPenalizacao = false;
            _cartaEspecialPendente = null;
            _indicePrimeiraCarta = 0;

            AtualizarInterface();
            AtualizarPontuacoes();

            Mensagem = "Jogo retomado com sucesso.";
        }

        private void InicializarColecoes()
        {
            Jogadores = new ObservableCollection<Jogador>();
            Bots = new ObservableCollection<Jogador>();
            MaoJogador = new ObservableCollection<Carta>();
            MaoJogadorVisivel = new ObservableCollection<Carta>();
        }

        private void InicializarComandos()
        {
            IniciarJogoCommand = new RelayCommand(_ => IniciarJogo());
            JogarCartaCommand = new RelayCommand(carta => JogarCarta(carta as Carta));
            ComprarCartaCommand = new RelayCommand(_ => ComprarCarta());
            GritarUnoCommand = new RelayCommand(_ => GritarUno());
            GuardarJogoCommand = new RelayCommand(_ => GuardarJogo());
            CarregarJogoCommand = new RelayCommand(_ => CarregarJogo());
            NovaPartidaCommand = new RelayCommand(_ => NovaPartida());
            NovoJogoCommand = new RelayCommand(_ => IniciarJogo());

            CartasAnterioresCommand = new RelayCommand(_ => CartasAnteriores());
            CartasSeguintesCommand = new RelayCommand(_ => CartasSeguintes());

            AbrirPausaCommand = new RelayCommand(_ => MenuPausaVisivel = true);
            FecharPausaCommand = new RelayCommand(_ => MenuPausaVisivel = false);

            AbrirEstatisticasCommand = new RelayCommand(_ =>
            {
                MenuPausaVisivel = false;
                EstatisticasVisivel = true;
            });

            FecharEstatisticasCommand = new RelayCommand(_ =>
            {
                EstatisticasVisivel = false;
                MenuPausaVisivel = true;
            });

            SairCommand = new RelayCommand(_ =>
            {
                MenuPausaVisivel = false;
                ConfirmarSaidaVisivel = true;
            });

            VoltarAoJogoCommand = new RelayCommand(_ =>
            {
                ConfirmarSaidaVisivel = false;
                EstatisticasVisivel = false;
                MenuPausaVisivel = false;
            });

            VoltarMenuCommand = new RelayCommand(_ =>
            {
                _xmlService.GuardarJogo(_jogo);

                var mainViewModel = Application.Current.MainWindow.DataContext as MainViewModel;

                if (mainViewModel != null)
                {
                    mainViewModel.ViewAtual = new MenuViewModel(
                        mainViewModel.EscolherBotsCommand,
                        mainViewModel.RetomarJogoCommand);
                }
            });

            GuardarESairCommand = new RelayCommand(_ =>
            {
                _xmlService.GuardarJogo(_jogo);
                System.Windows.Application.Current.Shutdown();
            });

            SairSemGuardarCommand = new RelayCommand(_ =>
            {
                System.Windows.Application.Current.Shutdown();
            });

            EscolherCorCommand = new RelayCommand(cor =>
            {
                if (cor == null)
                    return;

                if (cor is Cor corEnum)
                {
                    ConfirmarCorEscolhida(corEnum);
                    return;
                }

                Cor corConvertida;

                if (Enum.TryParse(cor.ToString(), out corConvertida))
                    ConfirmarCorEscolhida(corConvertida);
            });

            FecharPenalizacaoCommand = new RelayCommand(async _ =>
            {
                PenalizacaoUnoVisivel = false;

                if (_continuarBotsDepoisPenalizacao)
                {
                    _continuarBotsDepoisPenalizacao = false;
                    await JogarBots();
                }
            });
        }

        private async void IniciarJogo()
        {
            _jogo.IniciarJogo(_numeroBots);

            _partidaTerminada = false;
            MenuPausaVisivel = false;
            ConfirmarSaidaVisivel = false;
            EstatisticasVisivel = false;
            EscolhaCorVisivel = false;
            PenalizacaoUnoVisivel = false;

            _continuarBotsDepoisPenalizacao = false;

            _cartaEspecialPendente = null;

            _indicePrimeiraCarta = 0;

            CorEscolhida = Cor.Vermelho;

            AtualizarInterface();
            AtualizarPontuacoes();

            if (_jogo.JogadorAtual.EhBot)
            {
                Mensagem = _jogo.JogadorAtual.Nome + " começa a partida.";

                await Task.Delay(2000);

                await JogarBots();
            }
            else
            {
                Mensagem = "Começas tu.";
            }
        }

        private async void NovaPartida()
        {
            if (_partidaTerminada)
            {
                _xmlService.GuardarJogo(_jogo);
            }

            _jogo.IniciarNovaPartida();

            _partidaTerminada = false;
            MenuPausaVisivel = false;
            EscolhaCorVisivel = false;
            PenalizacaoUnoVisivel = false;
            _continuarBotsDepoisPenalizacao = false;
            _cartaEspecialPendente = null;
            _indicePrimeiraCarta = 0;
            CorEscolhida = Cor.Vermelho;

            AtualizarInterface();
            AtualizarPontuacoes();

            if (_jogo.JogadorAtual.EhBot)
            {
                Mensagem = _jogo.JogadorAtual.Nome + " começa a partida.";
                await Task.Delay(2000);
                await JogarBots();
            }
            else
            {
                Mensagem = "Nova partida iniciada. Começas tu.";
            }
        }

        private void GuardarJogo()
        {
            _xmlService.GuardarJogo(_jogo);
            Mensagem = "Jogo guardado com sucesso!";
        }

        private void CarregarJogo()
        {
            var jogoCarregado = _xmlService.CarregarJogo();

            if (jogoCarregado == null)
            {
                Mensagem = "Não existe jogo guardado.";
                return;
            }

            _jogo = jogoCarregado;
            _partidaTerminada = _jogo.VerificarVencedor();
            _indicePrimeiraCarta = 0;
            EscolhaCorVisivel = false;
            PenalizacaoUnoVisivel = false;
            _continuarBotsDepoisPenalizacao = false;
            _cartaEspecialPendente = null;

            AtualizarInterface();
            AtualizarPontuacoes();

            Mensagem = "Jogo carregado com sucesso.";
        }

        private async void JogarCarta(Carta carta)
        {
            if (_partidaTerminada || carta == null || MenuPausaVisivel || EscolhaCorVisivel || PenalizacaoUnoVisivel)
                return;

            if (!_jogo.PodeJogar(carta))
            {
                Mensagem = "Não podes jogar essa carta.";
                return;
            }

            if (carta.Tipo == TipoCarta.Coringa || carta.Tipo == TipoCarta.MaisQuatro)
            {
                _cartaEspecialPendente = carta;
                EscolhaCorVisivel = true;
                Mensagem = "Escolhe uma cor para continuar.";
                return;
            }

            await JogarCartaNormal(carta);
        }

        private async Task JogarCartaNormal(Carta carta)
        {
            string mensagemEspecial = ObterMensagemCartaEspecial(_jogo.JogadorAtual.Nome, carta);

            _jogo.JogarCarta(carta);

            var humano = _jogo.Jogadores.FirstOrDefault(j => !j.EhBot);

            Mensagem = mensagemEspecial;
            AtualizarInterface();

            if (VerificarFimPartida())
                return;

            if (await VerificarPenalizacaoUnoDepoisDaJogada(humano))
                return;

            if (humano != null)
                humano.DisseUno = false;

            await JogarBots();
        }

        private async void ConfirmarCorEscolhida(Cor cor)
        {
            if (_cartaEspecialPendente == null)
                return;

            CorEscolhida = cor;
            EscolhaCorVisivel = false;

            string mensagemEspecial = ObterMensagemCartaEspecial(_jogo.JogadorAtual.Nome, _cartaEspecialPendente);

            _jogo.JogarCarta(_cartaEspecialPendente, CorEscolhida);

            var humano = _jogo.Jogadores.FirstOrDefault(j => !j.EhBot);

            Mensagem = mensagemEspecial + " Cor escolhida: " + CorEscolhida + ".";

            _cartaEspecialPendente = null;

            AtualizarInterface();

            if (VerificarFimPartida())
                return;

            if (await VerificarPenalizacaoUnoDepoisDaJogada(humano))
                return;

            if (humano != null)
                humano.DisseUno = false;

            await JogarBots();
        }

        private async Task<bool> VerificarPenalizacaoUnoDepoisDaJogada(Jogador humano)
        {
            if (humano == null)
                return false;

            if (humano.Mao.Count == 1 && !humano.DisseUno)
            {
                AtualizarInterface();

                await Task.Delay(2000);

                if (humano.Mao.Count == 1 && !humano.DisseUno)
                {
                    humano.ComprarCarta(_jogo.Baralho.ComprarCarta());
                    humano.ComprarCarta(_jogo.Baralho.ComprarCarta());

                    PenalizacaoJogador = humano.Nome;
                    PenalizacaoUnoVisivel = true;
                    _continuarBotsDepoisPenalizacao = true;

                    Mensagem = "Não gritaste UNO a tempo. Compraste 2 cartas.";
                    humano.DisseUno = false;

                    AtualizarInterface();

                    return true;
                }
            }

            return false;
        }

        private async Task JogarBots()
        {
            while (_jogo.JogadorAtual.EhBot && !_partidaTerminada)
            {
                if (MenuPausaVisivel || EscolhaCorVisivel || PenalizacaoUnoVisivel)
                    return;

                await Task.Delay(2000);

                if (MenuPausaVisivel || EscolhaCorVisivel || PenalizacaoUnoVisivel)
                    return;

                var bot = _jogo.JogadorAtual;
                var cartaJogavel = bot.Mao.FirstOrDefault(c => _jogo.PodeJogar(c));

                if (cartaJogavel != null)
                {
                    string mensagemEspecial = ObterMensagemCartaEspecial(bot.Nome, cartaJogavel);

                    if (cartaJogavel.Tipo == TipoCarta.Coringa || cartaJogavel.Tipo == TipoCarta.MaisQuatro)
                    {
                        var melhorCor = EscolherMelhorCorBot(bot);
                        CorEscolhida = melhorCor;
                        _jogo.JogarCarta(cartaJogavel, melhorCor);
                        Mensagem = mensagemEspecial + " Cor escolhida: " + melhorCor + ".";
                    }
                    else
                    {
                        _jogo.JogarCarta(cartaJogavel);
                        Mensagem = bot.Mao.Count == 1 ? bot.Nome + " gritou UNO!" : mensagemEspecial;
                    }
                }
                else
                {
                    _jogo.ComprarCarta();
                    Mensagem = bot.Nome + " comprou uma carta.";

                    AtualizarInterface();

                    await Task.Delay(2000);

                    if (MenuPausaVisivel || EscolhaCorVisivel || PenalizacaoUnoVisivel)
                        return;

                    var novaCarta = bot.Mao.LastOrDefault();

                    if (novaCarta != null && _jogo.PodeJogar(novaCarta))
                    {
                        string mensagemEspecial = ObterMensagemCartaEspecial(bot.Nome, novaCarta);

                        if (novaCarta.Tipo == TipoCarta.Coringa || novaCarta.Tipo == TipoCarta.MaisQuatro)
                        {
                            var melhorCor = EscolherMelhorCorBot(bot);
                            CorEscolhida = melhorCor;
                            _jogo.JogarCarta(novaCarta, melhorCor);
                            Mensagem = mensagemEspecial + " Cor escolhida: " + melhorCor + ".";
                        }
                        else
                        {
                            _jogo.JogarCarta(novaCarta);
                            Mensagem = bot.Mao.Count == 1 ? bot.Nome + " gritou UNO!" : mensagemEspecial;
                        }
                    }
                    else
                    {
                        _jogo.ProximoJogador();
                    }
                }

                AtualizarInterface();

                if (VerificarFimPartida())
                    return;
            }

            if (!_partidaTerminada && !MenuPausaVisivel && !EscolhaCorVisivel && !PenalizacaoUnoVisivel)
                Mensagem = "É a tua vez!";
        }

        private string ObterMensagemCartaEspecial(string nomeJogador, Carta carta)
        {
            switch (carta.Tipo)
            {
                case TipoCarta.MaisDois:
                    return nomeJogador + " jogou +2. O próximo jogador compra 2 cartas e perde a vez.";

                case TipoCarta.MaisQuatro:
                    return nomeJogador + " jogou +4. O próximo jogador compra 4 cartas e perde a vez.";

                case TipoCarta.Bloquear:
                    return nomeJogador + " jogou Bloquear. O próximo jogador foi saltado.";

                case TipoCarta.Inverter:
                    return nomeJogador + " jogou Inverter. O sentido do jogo mudou.";

                case TipoCarta.Coringa:
                    return nomeJogador + " jogou Coringa.";

                default:
                    return nomeJogador + " jogou " + carta.TextoCarta + ".";
            }
        }

        private bool VerificarFimPartida()
        {
            if (!_jogo.VerificarVencedor())
                return false;

            _partidaTerminada = true;

            var vencedor = _jogo.ObterVencedor();
            _jogo.CalcularPontosRodada();
            _jogo.AtribuirPontosAoVencedor();

            AtualizarPontuacoes();
            AtualizarInterface();

            if (vencedor != null)
                Mensagem = vencedor.Nome + " ganhou!";

            return true;
        }

        private Cor EscolherMelhorCorBot(Jogador bot)
        {
            var cores = bot.Mao
                .Where(c => c.Cor != Cor.Especial)
                .GroupBy(c => c.Cor)
                .OrderByDescending(g => g.Count())
                .FirstOrDefault();

            if (cores != null)
                return cores.Key;

            return Cor.Vermelho;
        }

        private async void ComprarCarta()
        {
            if (_partidaTerminada || MenuPausaVisivel || EscolhaCorVisivel || PenalizacaoUnoVisivel)
                return;

            var humano = _jogo.JogadorAtual;

            _jogo.ComprarCarta();

            var cartaComprada = humano.Mao.LastOrDefault();

            AtualizarInterface();

            if (cartaComprada != null && _jogo.PodeJogar(cartaComprada))
            {
                Mensagem = "Compraste uma carta jogável. Podes jogá-la agora.";
                return;
            }

            Mensagem = "Compraste uma carta, mas não podes jogá-la. Passa a vez.";

            _jogo.ProximoJogador();

            await JogarBots();
        }

        private void GritarUno()
        {
            var humano = _jogo.Jogadores.FirstOrDefault(j => !j.EhBot);

            if (humano == null || _partidaTerminada || MenuPausaVisivel || EscolhaCorVisivel || PenalizacaoUnoVisivel)
                return;

            if (humano.Mao.Count == 1)
            {
                humano.DisseUno = true;
                Mensagem = humano.Nome + " gritou UNO!";
            }
            else
            {
                humano.ComprarCarta(_jogo.Baralho.ComprarCarta());
                humano.ComprarCarta(_jogo.Baralho.ComprarCarta());

                PenalizacaoJogador = humano.Nome;
                PenalizacaoUnoVisivel = true;

                Mensagem = "Disseste UNO antes do tempo. Compraste 2 cartas.";

                AtualizarInterface();
            }
        }

        private void AtualizarInterface()
        {
            Jogadores.Clear();
            Bots.Clear();
            MaoJogador.Clear();

            foreach (var jogador in _jogo.Jogadores)
            {
                Jogadores.Add(jogador);

                if (jogador.EhBot)
                    Bots.Add(jogador);
            }

            var humano = _jogo.Jogadores.FirstOrDefault(j => !j.EhBot);

            if (humano != null)
            {
                foreach (var carta in humano.Mao)
                    MaoJogador.Add(carta);
            }

            CartaTopo = _jogo.CartaTopo;

            AtualizarMaoVisivel();

            OnPropertyChanged(nameof(DirecaoTexto));
            OnPropertyChanged(nameof(CorAtual));
        }

        private void AtualizarMaoVisivel()
        {
            MaoJogadorVisivel.Clear();

            if (_indicePrimeiraCarta < 0)
                _indicePrimeiraCarta = 0;

            if (_indicePrimeiraCarta > MaoJogador.Count - MaxCartasVisiveis)
                _indicePrimeiraCarta = Math.Max(0, MaoJogador.Count - MaxCartasVisiveis);

            foreach (var carta in MaoJogador.Skip(_indicePrimeiraCarta).Take(MaxCartasVisiveis))
            {
                MaoJogadorVisivel.Add(carta);
            }
        }

        private void CartasAnteriores()
        {
            _indicePrimeiraCarta -= MaxCartasVisiveis;

            if (_indicePrimeiraCarta < 0)
                _indicePrimeiraCarta = 0;

            AtualizarMaoVisivel();
        }

        private void CartasSeguintes()
        {
            if (_indicePrimeiraCarta + MaxCartasVisiveis < MaoJogador.Count)
            {
                _indicePrimeiraCarta += MaxCartasVisiveis;
                AtualizarMaoVisivel();
            }
        }

        private void AtualizarPontuacoes()
        {
            PontuacoesTexto = "";

            foreach (var jogador in _jogo.Jogadores)
            {
                PontuacoesTexto += jogador.Nome + ": "
                    + jogador.Pontos + " pontos"
                    + " | Partidas: "
                    + jogador.PartidasGanhas + "/"
                    + jogador.PartidasJogadas
                    + " | Jogos: "
                    + jogador.JogosGanhos + "/"
                    + jogador.JogosJogados
                    + "\n";
            }
        }
    }
}