﻿using System.Windows.Input;

namespace UNO.App.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        private string _nomeUtilizador;

        public string NomeUtilizador
        {
            get => _nomeUtilizador;
            set
            {
                _nomeUtilizador = value;
                OnPropertyChanged();
            }
        }

        public ICommand EntrarCommand { get; }

        public LoginViewModel(ICommand entrarCommand)
        {
            EntrarCommand = entrarCommand;
        }
    }
}