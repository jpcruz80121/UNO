﻿using System.Windows.Input;
using UNO.App.Commands;
using UNO.App.Services;

namespace UNO.App.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private readonly XmlService _xmlService = new XmlService();

        private BaseViewModel _viewAtual;
        public BaseViewModel ViewAtual
        {
            get => _viewAtual;
            set
            {
                _viewAtual = value;
                OnPropertyChanged();
            }
        }

        public ICommand EscolherBotsCommand { get; }
        public ICommand RetomarJogoCommand { get; }

        public MainViewModel()
        {
            EscolherBotsCommand = new RelayCommand(param =>
            {
                int numeroBots = int.Parse(param.ToString());
                ViewAtual = new JogoViewModel(numeroBots);
            });

            RetomarJogoCommand = new RelayCommand(param =>
            {
                var info = param as JogoGuardadoInfo;

                if (info == null)
                    return;

                var jogo = _xmlService.CarregarJogo(info.Caminho);

                if (jogo != null)
                    ViewAtual = new JogoViewModel(jogo);
            });

            ViewAtual = new MenuViewModel(EscolherBotsCommand, RetomarJogoCommand);
        }
    }
}