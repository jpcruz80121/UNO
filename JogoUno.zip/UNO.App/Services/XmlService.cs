﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using UNO.App.Models;

namespace UNO.App.Services
{
    public class JogoGuardadoInfo
    {
        public string Nome { get; set; }
        public string Caminho { get; set; }
        public DateTime Data { get; set; }
        public int NumeroJogadores { get; set; }
        public int NumeroBots { get; set; }
    }

    public class XmlService
    {
        private readonly string pastaSaves;

        public XmlService()
        {
            pastaSaves = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "UNO_Saves");

            if (!Directory.Exists(pastaSaves))
                Directory.CreateDirectory(pastaSaves);
        }

        public void GuardarJogo(Jogo jogo)
        {
            string nomeFicheiro = "jogo_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xml";
            string caminho = Path.Combine(pastaSaves, nomeFicheiro);

            XmlSerializer serializer = new XmlSerializer(typeof(Jogo));

            using (FileStream fs = new FileStream(caminho, FileMode.Create))
            {
                serializer.Serialize(fs, jogo);
            }
        }

        public Jogo CarregarJogo()
        {
            var ultimo = ListarJogosGuardados()
                .OrderByDescending(j => j.Data)
                .FirstOrDefault();

            if (ultimo == null)
                return null;

            return CarregarJogo(ultimo.Caminho);
        }

        public Jogo CarregarJogo(string caminho)
        {
            if (!File.Exists(caminho))
                return null;

            XmlSerializer serializer = new XmlSerializer(typeof(Jogo));

            using (FileStream fs = new FileStream(caminho, FileMode.Open))
            {
                return (Jogo)serializer.Deserialize(fs);
            }
        }

        public List<JogoGuardadoInfo> ListarJogosGuardados()
        {
            List<JogoGuardadoInfo> jogos = new List<JogoGuardadoInfo>();

            foreach (var ficheiro in Directory.GetFiles(pastaSaves, "*.xml"))
            {
                try
                {
                    var jogo = CarregarJogo(ficheiro);

                    int numeroBots = jogo?.Jogadores?.Count(j => j.EhBot) ?? 0;

                    jogos.Add(new JogoGuardadoInfo
                    {
                        Nome = numeroBots == 1
                            ? "Partida vs 1 Bot"
                            : "Partida vs " + numeroBots + " Bots",

                        Caminho = ficheiro,
                        Data = File.GetLastWriteTime(ficheiro),
                        NumeroJogadores = jogo?.Jogadores?.Count ?? 0,
                        NumeroBots = numeroBots
                    });
                }
                catch
                {
                }
            }

            return jogos
                .OrderByDescending(j => j.Data)
                .ToList();
        }
    }
}